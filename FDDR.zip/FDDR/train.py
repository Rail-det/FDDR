import os
from net import Mnet
import torch
from torch import nn
import random
import numpy as np
import torch.optim as optim
from torch.utils.data import DataLoader, ConcatDataset
from lib.dataset_lable import Data
from lib.data_prefetcher_label import DataPrefetcher
from torch.nn import functional as F
import pytorch_iou

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
IOU = pytorch_iou.IOU(size_average=True)


def loss_1(score1, s1, label):

    score1 = F.interpolate(score1, label.shape[2:], mode='bilinear', align_corners=True)
    s1 = F.interpolate(s1, label.shape[2:], mode='bilinear', align_corners=True)
    sal_loss1 = F.binary_cross_entropy_with_logits(score1, label, reduction='mean')

    loss1 = IOU(s1, label) + sal_loss1


    return loss1


def loss_2(score1_aug, s1_aug, label, epoch):

    if epoch <= 25:
        score1 = F.interpolate(score1_aug, label.shape[2:], mode='bilinear', align_corners=True)
        s1 = F.interpolate(s1_aug, label.shape[2:], mode='bilinear', align_corners=True)
        sal_loss1 = F.binary_cross_entropy_with_logits(score1, label, reduction='mean')
        loss = IOU(s1, label) + sal_loss1
    else:
        score1 = F.interpolate(score1_aug, label.shape[2:], mode='bilinear', align_corners=True)
        s1 = F.interpolate(s1_aug, label.shape[2:], mode='bilinear', align_corners=True)
        sal_loss1 = F.binary_cross_entropy_with_logits(score1, label, reduction='mean')
        loss = IOU(s1, label) + sal_loss1

    return loss


def KL_divergence(logvar, mu):
    kld = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp(), dim=-1)
    return kld.mean()


if __name__ == '__main__':
    random.seed(118)
    np.random.seed(118)
    torch.manual_seed(118)
    torch.cuda.manual_seed(118)
    torch.cuda.manual_seed_all(118)
    # dataset

    type1_root = '/dataset/Type_I/'
    type2_root = '/dataset/Type_II/'
    neu1_root = '/dataset/neu_1/'
    neu2_root = '/dataset/neu_2/'
    steel_root = '/dataset/steel/'
    frsd_root = '/dataset/FRSD/'

    save_path = './model'
    if not os.path.exists(save_path): os.mkdir(save_path)
    lr = 0.001
    batch_size = 3
    epoch = 80
    lr_dec = [100, 120]

    #   TYPE1:0 ; TYPE2:1;  NEU113: 2; NEU2 :3 ;STEEL:4; TILE:5

    type1_data = Data(type1_root, 0)
    type2_data = Data(type2_root, 1)
    neu1_data = Data(neu1_root, 2)
    neu2_data = Data(neu2_root, 3)
    steel_data = Data(steel_root, 4)
    frsd_data = Data(frsd_root, 5)

    #  init net
    net = Mnet().cuda()
    optimizer = optim.SGD(filter(lambda p: p.requires_grad, net.parameters()), lr=lr, weight_decay=0.0005, momentum=0.9)
    net.train()

    l1_distance = nn.L1Loss()

    num_params = 0
    for p in net.parameters():
        num_params += p.numel()
    print(num_params)

    for epochi in range(1, epoch + 1):
        if epochi in lr_dec:
            lr = lr / 10
            optimizer = optim.SGD(filter(lambda p: p.requires_grad, net.parameters()), lr=lr, weight_decay=0.0005,
                                  momentum=0.9)

            print(lr)

        domain_dataset_list = [neu2_data, type2_data, neu1_data, frsd_data, type1_data]

        domain_list = np.random.permutation(5)
        meta_train_domain_list = domain_list[:5]
        meta_train_dataset = ConcatDataset([domain_dataset_list[meta_train_domain_list[0]],
                                            domain_dataset_list[meta_train_domain_list[1]],
                                            domain_dataset_list[meta_train_domain_list[2]],
                                            domain_dataset_list[meta_train_domain_list[3]],
                                            domain_dataset_list[meta_train_domain_list[4]],
                                            ])
        meta_train_loader = DataLoader(meta_train_dataset, batch_size=batch_size, shuffle=True, num_workers=4)
        prefetcher = DataPrefetcher(meta_train_loader)
        rgb, label, cla = prefetcher.next()

        iter_num = len(meta_train_loader)

        seg_loss_value = 0
        reimg_loss_value = 0
        kl_loss_value = 0
        cont_loss_value = 0
        aug_value = 0

        net.zero_grad()
        i = 0

        for j in range(iter_num):
            i += 1

            score1, s1, re_img, img_aug, z_out, mu_out, logvar_out, d1, d1_aug, score1_aug, s1_aug, saw_loss = net(rgb)

            seg_loss = loss_1(score1, s1, label)
            aug_seg_loss = loss_2(score1_aug, s1_aug, label, epochi)
            reimg_loss = l1_distance(re_img, rgb)
            kl_loss = KL_divergence(logvar_out, mu_out)
            cont_loss = l1_distance(d1, d1_aug)

            seg_loss_value += seg_loss.data
            reimg_loss_value += reimg_loss.data
            kl_loss_value += kl_loss.data
            cont_loss_value += cont_loss.data
            aug_value += aug_seg_loss.data

            train_loss = seg_loss + 0.1 * reimg_loss + 0.1 * kl_loss + cont_loss * 0.01 + aug_seg_loss + saw_loss * 0.2
            train_loss.backward()

            optimizer.step()
            optimizer.zero_grad()

            if i % 50 == 0:
                print('epoch: [%2d/%2d], iter: [%5d/%5d] || seg_loss : %5.4f|| augseg_loss : %5.4f|| reimg_loss : %5.4f|| kl_loss : %5.4f|| cont_loss : %5.4f || lr:%6.5f' % (
                    epochi, epoch, i, iter_num, seg_loss_value / 50, aug_value / 50, reimg_loss_value / 50, kl_loss_value / 50, cont_loss_value / 50, lr))
                seg_loss_value = 0
                reimg_loss_value = 0
                kl_loss_value = 0
                cont_loss_value = 0
                aug_value = 0

            rgb, label, cla = prefetcher.next()

        if epochi >= 5 and epochi % 5 == 0:
            torch.save(net.state_dict(), '%s/epoch_%d.pth' % (save_path, epochi))
    torch.save(net.state_dict(), '%s/final.pth' % (save_path))
