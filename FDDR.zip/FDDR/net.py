import torch
from torch import nn
import torch.nn.functional as F
import mix_transformer
from layers.blocks import *
from layers.adain import *
from layers.IW import SWM


def convblock(in_, out_, ks, st, pad):
    return nn.Sequential(
        nn.Conv2d(in_, out_, ks, st, pad),
        nn.BatchNorm2d(out_),
        nn.ReLU(inplace=True)
    )


class AdaINDecoder(nn.Module):
    def __init__(self, content_out_channels):
        super().__init__()
        self.content_out_channels = content_out_channels
        self.conv1 = conv_relu(self.content_out_channels, 128, 3, 1, 1)
        self.conv2 = conv_relu(128, 64, 3, 1, 1)
        self.conv3 = conv_relu(64, 32, 3, 1, 1)
        self.conv4 = conv_no_activ(32, 3, 3, 1, 1)

    def forward(self, content_fea, style_fea):
        out = adaptive_instance_normalization(content_fea, style_fea)
        out = self.conv1(out)
        out = adaptive_instance_normalization(out, style_fea)
        out = self.conv2(out)
        out = adaptive_instance_normalization(out, style_fea)
        out = self.conv3(out)
        out = adaptive_instance_normalization(out, style_fea)
        out = self.conv4(out)
        # out = F.tanh(self.conv4(out))

        return out


class Decoder(nn.Module): 
    def __init__(self, content_out_channels, style_length, num_mask_channels):

        super(Decoder, self).__init__()
        self.content_out_channels = content_out_channels
        self.style_length = style_length
        self.num_mask_channels = num_mask_channels
        self.decoder = AdaINDecoder(self.content_out_channels)

    def forward(self, content, style):

        out = self.decoder(content, style)

        return out


class VAE_Encoder(nn.Module):
    def __init__(self, style_length):
        super(VAE_Encoder, self).__init__()

        self.style_length = style_length

        self.block1 = conv_bn_lrelu(3, 16, 3, 2, 1)  # 内容编码器输出的通道数：8  原图通道数：3  224->112  384
        self.block2 = conv_bn_lrelu(16, 32, 3, 2, 1)  # 112-> 56
        self.block3 = conv_bn_lrelu(32, 64, 3, 2, 1)  # 56-> 28
        self.block4 = conv_bn_lrelu(64, 128, 3, 2, 1)  # 28->14
        self.fc = nn.Linear(25088, 32)  # 128 * 14 *14 = 25088
        self.norm = nn.BatchNorm1d(32)
        self.activ = nn.LeakyReLU(0.03, inplace=True)
        self.mu = nn.Linear(32, self.style_length)
        self.logvar = nn.Linear(32, self.style_length)

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)

        return mu + eps * std

    def encode(self, x):
        return self.mu(x), self.logvar(x)

    def forward(self, a, x):
        # out = torch.cat([a, x], 1)
        out = F.interpolate(x, (224, 224), mode='bilinear', align_corners=True)
        out = self.block1(out)
        out = self.block2(out)
        out = self.block3(out)
        out = self.block4(out)
        out = self.fc(out.view(-1, out.shape[1] * out.shape[2] * out.shape[3]))
        out = self.norm(out)
        out = self.activ(out)

        mu, logvar = self.encode(out)
        z = self.reparameterize(mu, logvar)

        return z, mu, logvar


class Fuse(nn.Module):
    def __init__(self, ch_1, ch_2):
        super(Fuse, self).__init__()
        self.ch2 = ch_2
        self.conv_pre = convblock(ch_1, ch_2, 3, 1, 1)

    def forward(self, rgb, pre):
        cur_size = rgb.size()[2:]

        pre = self.conv_pre(F.interpolate(pre, cur_size, mode='bilinear', align_corners=True))

        fus = pre + rgb

        return fus


class Seg_Decoder(nn.Module):
    def __init__(self):
        super(Seg_Decoder, self).__init__()

        self.d3 = Fuse(512, 320)
        self.d2 = Fuse(320, 128)
        self.d1 = Fuse(128, 64)

        self.conv1 = conv_bn_relu(64, 128, 3, 1, 1)
        self.conv2 = conv_bn_relu(128, 64, 3, 1, 1)
        self.pred = nn.Conv2d(64, 1, 1, 1, 0)

        self.content_d1 = nn.Conv2d(64, 8, 1, 1, 0)

    def forward(self, rgb):

        d4 = rgb[3]
        d3 = self.d3(rgb[2], d4)
        d2 = self.d2(rgb[1], d3)
        d1 = self.d1(rgb[0], d2)

        pre = self.conv1(d1)
        pre = self.conv2(pre)
        pre = self.pred(pre)

        d1_content = self.content_d1(d1)

        return pre, d1_content


class Segformer(nn.Module):
    def __init__(self, backbone, pretrained=None):
        super().__init__()

        self.encoder = getattr(mix_transformer, backbone)()

        if pretrained:
            state_dict = torch.load(backbone + '.pth')
            state_dict.pop('head.weight')
            state_dict.pop('head.bias')
            self.encoder.load_state_dict(state_dict, )

    def forward(self):
        model = Segformer('mit_b3', pretrained=True)
        return model



class Content_Enc(nn.Module):
    def __init__(self, backbone="mit_b3", pretrained=True):
        super(Content_Enc, self).__init__()

        net = Segformer(backbone, pretrained)
        self.rgb_encoder = net.encoder

        self.sigmoid = nn.Sigmoid()

        self.saw1 = SWM(32, 64, relax_denom=2.0)
        self.saw2 = SWM(32, 128, relax_denom=2.0)

    def forward(self, rgb):
        # rgb
        B = rgb.shape[0]
        Hig = rgb.shape[2]
        rgb_f = []

        # stage 1
        x, H, W = self.rgb_encoder.patch_embed1(rgb)
        for i, blk in enumerate(self.rgb_encoder.block1):
            x = blk(x, H, W)
        x = self.rgb_encoder.norm1(x)
        x = x.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        saw_loss1 = self.saw1(x)
        rgb_f.append(x)

        # stage 2
        x, H, W = self.rgb_encoder.patch_embed2(x)
        for i, blk in enumerate(self.rgb_encoder.block2):
            x = blk(x, H, W)
        x = self.rgb_encoder.norm2(x)
        x = x.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        saw_loss2 = self.saw2(x)
        rgb_f.append(x)

        # stage 3
        x, H, W = self.rgb_encoder.patch_embed3(x)
        for i, blk in enumerate(self.rgb_encoder.block3):
            x = blk(x, H, W)
        x = self.rgb_encoder.norm3(x)
        x = x.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        rgb_f.append(x)

        # stage 4
        x, H, W = self.rgb_encoder.patch_embed4(x)
        for i, blk in enumerate(self.rgb_encoder.block4):
            x = blk(x, H, W)
        x = self.rgb_encoder.norm4(x)
        x = x.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous()
        rgb_f.append(x)

        loss_saw = saw_loss1+saw_loss2

        return rgb_f, loss_saw

class Mnet(nn.Module):
    def __init__(self):
        super(Mnet, self).__init__()

        self.content_encoder = Content_Enc()
        self.seg_decoder = Seg_Decoder()
        self.sigmoid = nn.Sigmoid()

        self.vae_encoder = VAE_Encoder(8)
        self.img_decoder = Decoder(8, 8, 8)

    def forward(self, rgb):
        # rgb

        rgb_f, saw_loss = self.content_encoder(rgb)
        score1, d1 = self.seg_decoder(rgb_f)
        d1_content = F.interpolate(d1, rgb.shape[2:], mode='bilinear', align_corners=True)

        z_out, mu_out, logvar_out = self.vae_encoder(d1_content, rgb)
        re_img = self.img_decoder(d1_content, z_out)
        z_aug = torch.randn_like(z_out)
        img_aug = self.img_decoder(d1_content, z_aug)
        rgb_aug, saw_aug_loss = self.content_encoder(img_aug)
        score1_aug,  d1_aug = self.seg_decoder(rgb_aug)

        return score1, self.sigmoid(score1), re_img, img_aug, z_out, mu_out, logvar_out, d1, d1_aug, \
               score1_aug, self.sigmoid(score1_aug), saw_loss
