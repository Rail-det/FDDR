import os
from torch.utils.data import DataLoader
from lib.dataset import Data
import torch.nn.functional as F
import torch
import cv2
from net import Mnet
import numpy as np

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
if __name__ == '__main__':
    model_path = './model/final.pth'
    out_path = './output'

    data = Data(root='/dataset/neu_1/', mode='test')


    loader = DataLoader(data, batch_size=1, shuffle=False)
    net = Mnet().cuda()
    print('loading model from %s...' % model_path)
    net.load_state_dict(torch.load(model_path))
    if not os.path.exists(out_path): os.mkdir(out_path)

    img_num = len(loader)
    net.eval()

    with torch.no_grad():
        for rgb, _, (H, W), name in loader:
            print(name[0])

            score1, s1, re_img, img_aug, z_out, mu_out, logvar_out, dis_fea, score1_aug, s1_aug, saw_loss = net(rgb.cuda().float())

            score = F.interpolate(score1, size=(H, W), mode='bilinear', align_corners=True)
            pred = np.squeeze(torch.sigmoid(score).cpu().data.numpy())

            pred[pred > 0.5] = 1
            pred[pred < 1] = 0

            cv2.imwrite(os.path.join(out_path, name[0][:-4] + '.png'), pred)




